create definer = root@localhost trigger update_customer_number
    before update
    on customer
    for each row
    SET NEW.Number = SHA1(NEW.Number);

