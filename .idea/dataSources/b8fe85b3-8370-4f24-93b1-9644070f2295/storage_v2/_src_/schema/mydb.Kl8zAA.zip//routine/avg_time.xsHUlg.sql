create
    definer = root@localhost procedure avg_time(IN phone varchar(45), IN date1 date, IN date2 date)
begin
declare first_error char(45);
declare second_error char(45);
set first_error = 'data error';
set second_error = 'number error';
if (date1<=date2) then
  if (phone in (select occupation.phone from occupation)) THEN
    BEGIN 
        CREATE TABLE if not EXISTS mydb.counter(name varchar(45), phone VARCHAR(45),count VARCHAR(45));
        TRUNCATE mydb.counter;
        INSERT into mydb.counter(
        
		select employee.First_name, occupation.phone, count(orders.Date)
		from (occupation inner join employee) inner join orders
		ON occupation.idOccupation = employee.idemployee
		AND employee.idemployee = orders.employee_idemployee
		WHERE occupation.phone = phone and orders.date between date1 and date2
		group by employee.First_name
            
        );
        SELECT * FROM mydb.counter;
    end;
    ELSE SELECT second_error;
    END IF;
ELSE SELECT first_error;
END IF;    
end;

