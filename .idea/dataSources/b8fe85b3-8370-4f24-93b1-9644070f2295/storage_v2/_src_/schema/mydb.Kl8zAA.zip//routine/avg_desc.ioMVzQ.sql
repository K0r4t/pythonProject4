create
    definer = root@localhost function avg_desc(name varchar(45)) returns double deterministic
begin
declare avg_len double;
select avg(CHAR_LENGTH(goods.Descreption)) into avg_len
from ((customer inner join orders) inner join goods) inner join order_to_goods
ON orders.idorder = order_to_goods.order_id
AND goods.idgoods = order_to_goods.goods_id
AND Customer_idCustomer = IdCustomer_info
where customer.First_name = name;
return avg_len;
end;

