create definer = root@localhost trigger employee_delete
    before delete
    on employee
    for each row
begin
UPDATE mydb.occupation SET employee_idemployee=1 WHERE employee_idemployee=Old.idemployee;
UPDATE mydb.orders SET employee_idemployee=1 WHERE employee_idemployee=Old.idemployee;
END;

