create definer = root@localhost trigger customer_number
    before insert
    on customer
    for each row
    SET NEW.Number = SHA1(NEW.Number);

